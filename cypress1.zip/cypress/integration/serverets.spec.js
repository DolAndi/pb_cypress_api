/// <reference types="cypress" />

describe('Testes na api serverest', ()=> {
    it('Deve trazer usuário administrador para login', () =>{
        cy.buscarUsuarioAdm()
    })
})