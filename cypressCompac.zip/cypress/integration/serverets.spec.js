/// <reference types="cypress" />

import Factory from'../dinamics/factory'

describe('Testes na api serverest', ()=> {
    it('Deve trazer usuário administrador para login', () =>{
        cy.buscarUsuarioAdm().then( usuario => {
            cy.wrap({email: usiario.email, password: usuario.password}).as('usarioParaLogin')
        })
        cy.get('@usuarioParaLogin').then( user => {
            cy.logar(user).then( res =>{
                expect(res.status).to.equal(200)
                expect(res.body).to,have,prosperty('authorization')
            })
        })

        cy.fixture('loginCredentials').then((user) => {
            cy.logar(user).then(res => {
                expect(res.status).to.equal(200)
                expect(res.body).to.have.prosperty('authorization')
                bearer = res.body.authorization
            })
        })
    })

    it("Deve cadastrar um produto válido com sucesso", () =>{

        let produto = Factory.gerarProdutoBody()
        cy.cadastrarProduto(bearer, produto).then( res =>{
            expect(res.status).to.equal(201)
            expect(res.body).to.have.all.keys('message', '_id')
        })
    })
})