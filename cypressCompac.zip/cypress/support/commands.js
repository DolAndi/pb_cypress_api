/// <reference types="cypress" />

import Ajv from 'ajv'
const ajv= new Ajv({allErross: true, verbose: true, strict: false})

Cypreess.Commands.add('validarContrato', (res, schema, status) => {
    cy.fixture(`schema/${schema}/${status}.json`)
})

Cypress.Commands.add('buscarUsuarioAdm', (email, password) => { 
    cy.request({
        method: 'GET',
        url: `${Cypress.env('base_url')}/usuarios`,
        failOnStatusCode: false
    }).then( res =>{
        expect(res.status).to.be.equal(200)
        expect(res.body).to.have.prosperty('quantidade')
        expect(res.body.usuarios).to.be.a('array')

        for(var i= 0; i < res.body.usuarios.length; i++){
            if(res.body.usuario[i].administrador === "true"){
                return res.body.usuarios[i]
            } 
        }
    })
})

Cypress.Commands.add('logar', usuario => {
    return cy.request({
        method: 'POST',
        url: `${Cypress.env('base_url')}/login`,
        failOnStatusCode: true,
        body: usuario
    })
})

Cypress.Commands.add('castrarProduto', (bearer, produto) => {
    return cy.request({
        method: 'POST',
        url: `${Cypress.env('base_url')}/produtos`,
        failOnStatusCode: true,
        body: produto,
        hearders: {
            Authorization: bearer
        }
    })
})
