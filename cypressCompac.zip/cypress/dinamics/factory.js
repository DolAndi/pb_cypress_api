import faker from 'faker'

export default class Factory {
    static gerarProdutoBody(){
        return {
            "nome": `Caneta ${faker.commerce.color()}`,
            "preco": faker.commerce.price(),
            "descricao": "Azul caneta",
            "quantidade": 381
        }
    }
}